Credits
=======

**GenSON** is written and maintained by `Jon Wolverton <https://github.com/wolverdude>`_.


Contributors
------------

- `David Kay <https://github.com/davek2>`_
- `KOLANICH <https://github.com/KOLANICH>`_
- `YehudaCorsia <https://github.com/YehudaCorsia>`_
- `Brad Sokol <https://github.com/bradsokol>`_
- `John Vandenberg <https://github.com/jayvdb>`_
- `shtutzim <https://github.com/shtutzim>`_
- `Mike Ralphson <https://github.com/MikeRalphson>`_
