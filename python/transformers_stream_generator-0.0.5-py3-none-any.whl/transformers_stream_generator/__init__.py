from .main import init_stream_support
